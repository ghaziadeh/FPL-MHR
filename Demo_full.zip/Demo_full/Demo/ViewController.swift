//
//  ViewController.swift
//  Demo
//
//  Created by Jordan Spana on 3/3/21.
//

import UIKit
import CocoaMQTT
import UniformTypeIdentifiers

class ViewController: UIViewController,UIDocumentPickerDelegate {

    let mqttClient = CocoaMQTT(clientID: "ios Device", host:"172.20.10.6", port: 1883)
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func didReceiveMemoryWarning(){
        super.didReceiveMemoryWarning()
    }

    
    @IBAction func Forward(_ sender: UIButton) {
        if sender.isEnabled {
            mqttClient.publish("rpi/gpio", withString: "forward")
            }
    }
    
    
    
    @IBAction func Backward(_ sender: UIButton) {
        if sender.isEnabled {
            mqttClient.publish("rpi/gpio", withString: "backward")
            }
    }
    
    

    
    
    @IBAction func Left(_ sender: UIButton) {
        if sender.isEnabled {
            mqttClient.publish("rpi/gpio", withString: "left")
            }
    }
    
    
    @IBAction func Right(_ sender: UIButton) {
        if sender.isEnabled {
            mqttClient.publish("rpi/gpio", withString: "right")
            }
    }
    
    
    
    @IBAction func Stop(_ sender: UIButton) {
        if sender.isEnabled {
            mqttClient.publish("rpi/gpio", withString: "stop")
            }
    }
    
    

    @IBOutlet weak var label: UILabel!
    @IBAction func Speed(_ sender: UISlider) {
        label.text = String(Int(sender.value))
        mqttClient.publish("rpi/gpio", withString: String(Int(sender.value)))
    
    }
    
    
    @IBAction func ConnectButton(_ sender: UIButton) {
     mqttClient.connect()
    }
    
    @IBAction func disconnectbutton(_ sender: UIButton) {
     mqttClient.disconnect()
    }
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    

    
    
    
    
    @IBAction func automatic(_ sender: Any) {
        
        let supportedFiles : [UTType] = [UTType.data]
        let controller = UIDocumentPickerViewController(forOpeningContentTypes: supportedFiles,asCopy: true)
        
        controller.delegate = self
        controller.allowsMultipleSelection = false
        
        present(controller, animated: true, completion: nil)
        
        
        
        
    }
    
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentAt url: URL) {
        
        print("the file was selected")
        
        let rows = NSArray(contentsOfCSVURL: url, options: CHCSVParserOptions.sanitizesFields)!
        
        for row in rows
        {
            print(row)
        }
        
    }
    
    
    
    
    
    
    
    
    
}

